// sets/places.js — bedroom, kitchen, street (queue) and desk. Each returns { GY, CX, M, ... }.
import { E, V, layer, rr, seg, circle, linGrad, glow, alpha, shade, mix, mood } from '/engine/core.js';
import * as FX from '/engine/fx2d.js';
import { drawFigure, POSES } from '/engine/rig2d.js';
import { todMood, roomGround } from './room.js';
import { EXTRAS } from '../cast.js';

const FS = () => V(1.6, 1.7);
const backWall = (g, M, GY) => { g.fillStyle = linGrad(g, 0, -E.H, 0, GY, [M.dark, M.wall]); g.fillRect(-E.W, -E.H, E.W * 3, GY + E.H); };
const floorOf = (g, M, GY) => {
  g.fillStyle = linGrad(g, 0, GY - 40, 0, GY + 600, [shade(M.floor, 0.1), M.dark]); g.fillRect(-E.W, GY - 40, E.W * 3, E.H * 2);
  FX.floorLines(g, GY - 40, GY + 600, 'rgba(0,0,0,.2)', 0.07);
};
const sunWin = (g, M, tod, x, y, w, h, cols = 2) => {
  const Mg = mood('golden');
  FX.windowFrame(g, { x, y, w, h, cols, frame: shade(M.wall, -0.55), bar: 9 }, (g, x, y, w, h) => {
    g.fillStyle = linGrad(g, 0, y, 0, y + h, M.sky); g.fillRect(x, y, w, h);
    if (tod < 0.85) { g.save(); g.globalAlpha = 1 - tod; FX.sun(g, x + w * 0.5, y + h * (0.55 + 0.5 * tod), 45, '#fff7e6', Mg.key, 4); g.restore(); }
    if (tod > 0.35) { g.save(); g.globalAlpha = (tod - 0.35) / 0.65; FX.stars(g, 0, { area: [x, y, w, h * 0.55], count: 35 }); g.restore(); }
    FX.skyline(g, { x, y: y + h, w, maxH: h * 0.55, color: alpha(shade(M.wall, -0.2), 0.8), windowColor: alpha(M.practical, 0.3 + 0.55 * tod), seed: 5 });
  });
};
const cool = () => mood('interiorCool').practical;

export function bedroom(g, t, cam, o = {}) {
  const tod = o.tod ?? 0, M = todMood(tod), GY = roomGround(), CX = E.W / 2, s = FS(), hx = o.hx ?? E.W * 0.4;
  layer(g, cam, 0.35, (g) => {
    backWall(g, M, GY);
    sunWin(g, M, tod, CX - V(120, 200) + V(260, 0), GY - V(560, 760), V(520, 440), V(330, 420));
    rr(g, E.W * 0.08, GY - V(560, 700), V(150, 120), V(190, 160), 8); g.fillStyle = shade(M.wall, -0.25); g.fill();
  });
  layer(g, cam, 0.8, (g) => {
    floorOf(g, M, GY);
    const bw = 380 * s, bx = hx - 150 * s, sh = 72 * s;
    g.fillStyle = shade(M.wall, -0.5); g.fillRect(bx - 12, GY - 230, 24, 230); g.fillRect(bx, GY - sh + 22, bw, sh - 22);
    rr(g, bx, GY - sh - 8, bw, 34, 14); g.fillStyle = mix('#5a5aa0', M.dark, 0.35 * tod); g.fill();
    rr(g, bx + 18, GY - sh - 32, 100, 30, 12); g.fillStyle = '#e8e4f4'; g.fill();
    rr(g, bx + bw * 0.55, GY - sh - 14, bw * 0.45, 30, 12); g.fillStyle = mix('#7a6ad0', M.dark, 0.3 * tod); g.fill();
    const nx = bx + bw + 24, nh = 74 * s;
    rr(g, nx, GY - nh, 96, nh, 8); g.fillStyle = shade(M.wall, -0.45); g.fill();
    seg(g, [[nx + 70, GY - nh], [nx + 70, GY - nh - 70]], 5, shade(M.wall, -0.5)); circle(g, nx + 70, GY - nh - 84, 26, alpha(M.practical, 0.4 + 0.5 * tod));
    glow(g, nx + 70, GY - nh - 84, 200, M.practical, 0.12 + 0.4 * tod);
    if (o.phoneGlow) { rr(g, nx + 10, GY - nh - 8, 46, 8, 3); g.fillStyle = '#0c0c12'; g.fill(); glow(g, nx + 33, GY - nh - 10, 110, cool(), 0.3 + 0.1 * Math.sin(t * 7)); }
    FX.pool(g, CX + V(260, 0), GY + 10, 380, 60, M.key, 0.22 * (1 - 0.6 * tod));
  });
  return { GY, CX, M };
}

export function kitchen(g, t, cam, o = {}) {
  const tod = o.tod ?? 0.1, M = todMood(tod), GY = roomGround(), CX = E.W / 2;
  const ch = V(170, 200), top = GY - 10 - ch, kx = E.W * V(0.66, 0.72);
  layer(g, cam, 0.35, (g) => {
    backWall(g, M, GY);
    sunWin(g, M, tod, CX - V(420, 380), GY - V(560, 700), V(420, 380), V(280, 330));
    for (let i = 0; i < 6; i++) { rr(g, i * E.W * 0.19 - 20, GY - V(700, 880), E.W * 0.18, V(200, 220), 8); g.fillStyle = shade(M.wall, -0.3 - (i % 2) * 0.05); g.fill(); }
  });
  layer(g, cam, 0.8, (g) => {
    floorOf(g, M, GY);
    FX.counter(g, { x: -E.W, y: GY - 10, w: E.W * 3, h: ch, color: shade(M.wall, -0.45), top: shade(M.wall, -0.15), doors: 10 });
    rr(g, kx - 45, top - 80, 90, 80, 22); g.fillStyle = '#cfd6df'; g.fill();
    seg(g, [[kx + 40, top - 60], [kx + 76, top - 84]], 9, '#cfd6df'); circle(g, kx, top - 84, 10, '#9aa3ad');
    seg(g, [[kx - 46, top - 66], [kx - 70, top - 50], [kx - 46, top - 22]], 7, '#9aa3ad');
    for (let i = 0; i < 4; i++) { const u = ((t * 0.5 + i * 0.25) % 1); circle(g, kx + 78 + Math.sin(t * 2 + i) * 10, top - 90 - u * 150, 12 + u * 16, alpha('#ffffff', 0.22 * (1 - u))); }
    glow(g, kx, top - 40, 140, '#ffb070', 0.14);
  });
  return { GY, CX, M };
}

export function street(g, t, cam, o = {}) {
  const tod = o.tod ?? 0.6, M = todMood(tod), GY = roomGround(), CX = E.W / 2;
  layer(g, cam, 0.25, (g) => {
    g.fillStyle = linGrad(g, 0, -E.H, 0, GY, M.sky); g.fillRect(-E.W, -E.H, E.W * 3, GY + E.H);
    FX.skyline(g, { x: -E.W, y: GY - 30, w: E.W * 3, maxH: V(380, 520), color: shade(M.wall, -0.3), windowColor: alpha(M.practical, 0.5), seed: 9 });
  });
  layer(g, cam, 0.55, (g) => {
    FX.facade(g, { x: -80, y: GY - 20, w: E.W * 0.36, h: V(680, 900), color: shade(M.wall, -0.3), win: M.practical, dark: M.dark, cols: 4, rows: 4, lit: 0.5, seed: 3 });
    FX.facade(g, { x: E.W * 0.66, y: GY - 20, w: E.W * 0.4, h: V(620, 820), color: shade(M.wall, -0.35), win: M.practical, dark: M.dark, cols: 4, rows: 4, lit: 0.5, seed: 8 });
  });
  layer(g, cam, 0.8, (g) => {
    g.fillStyle = linGrad(g, 0, GY - 40, 0, GY + 600, [shade(M.floor, 0.05), M.dark]); g.fillRect(-E.W, GY - 40, E.W * 3, E.H * 2);
    FX.floorLines(g, GY - 40, GY + 600, 'rgba(0,0,0,.2)', 0.07);
    FX.lampPost(g, CX + V(380, 260), GY, V(420, 520), { light: M.practical, a: 0.2 });
  });
  if (o.queue) layer(g, cam, 1, (g) => {
    const s = FS() * 0.92;
    [0.18, 0.3, 0.7, 0.82, 0.94].forEach((fx, i) => {
      drawFigure(g, { x: E.W * fx, y: GY, s, facing: 1, outfit: EXTRAS[i % EXTRAS.length], pose: POSES.phone, expr: 'neutral', prop: 'phone', rim: { color: M.rim, dir: [0, -1], w: 3 } });
      glow(g, E.W * fx + 30 * s, GY - 190 * s, 90 * s, cool(), 0.12);
    });
  });
  return { GY, CX, M };
}

export function desk(g, t, cam, o = {}) {
  const tod = o.tod ?? 0.1, M = todMood(tod), GY = roomGround(), CX = E.W / 2, s = FS(), hx = o.hx ?? E.W * 0.4, top = GY - 95 * s;
  layer(g, cam, 0.35, (g) => {
    backWall(g, M, GY);
    sunWin(g, M, tod, CX + V(260, -260), GY - V(560, 760), V(500, 420), V(300, 380));
    rr(g, E.W * 0.1, GY - V(560, 700), V(190, 150), V(240, 200), 8); g.fillStyle = shade(M.wall, -0.25); g.fill();
  });
  layer(g, cam, 0.8, (g) => {
    floorOf(g, M, GY);
    FX.chair(g, hx - 6 * s, GY, s, shade(M.wall, -0.5));
    rr(g, E.W * 0.22, top, E.W * V(0.56, 0.74), 18, 6); g.fillStyle = shade(M.wall, -0.4); g.fill();
    g.fillStyle = shade(M.wall, -0.5); g.fillRect(E.W * 0.24, top + 18, 16, GY - top - 18); g.fillRect(E.W * V(0.76, 0.94), top + 18, 16, GY - top - 18);
    const sx = hx + 70 * s;
    FX.screen(g, { x: sx, y: top - 170, w: 230, h: 150, bg: '#1b2733', glowC: M.practical, a: 0.16 }, (g, x, y, w, h) => {
      for (let i = 0; i < 6; i++) { rr(g, x + 16, y + 18 + i * 20, (w - 40) * (0.5 + 0.45 * ((i * 37) % 10) / 10), 8, 4); g.fillStyle = alpha('#e8f0ff', 0.35); g.fill(); }
    });
    rr(g, sx - 24, top - 12, 280, 12, 5); g.fillStyle = shade(M.wall, -0.15); g.fill();
    if (o.phone) {
      const px = sx + 330;
      rr(g, px, top - 9, 62, 9, 3); g.fillStyle = '#0c0c12'; g.fill();
      if (o.phone === 'lit') glow(g, px + 31, top - 12, 150, cool(), 0.35 + 0.15 * Math.sin(t * 10));
      else if (o.phone === 'up') glow(g, px + 31, top - 12, 90, cool(), 0.22);
    }
  });
  return { GY, CX, M, top };
}
