// shots/10_kinds.js — shot renderers. Each shot id in SPECS picks one of these by its "k" field.
import { E, V, registerShot, mood, layer, blurLayer, veil, ease, prog, S, rr, seg, circle, glow, alpha, shade, mix, linGrad, text, clamp, lerp, rng } from '/engine/core.js';
import { drawFigure, POSES, bigFace } from '/engine/rig2d.js';
import * as FX from '/engine/fx2d.js';
import * as UI from '/engine/ui2d.js';
import { roomGround } from '../sets/room.js';
import { YOU, FRIEND, CAST } from '../cast.js';
import { PL, val, P01, camOf, coolC, voidBg, bpBg, hero, overlays, phoneDraw } from './00_core.js';
import { SPECS } from './20_specs.js';

const K = {};
const GOLD = () => S().ui.gold, CREAM = () => S().ui.cream;
const Y = (v, d) => E.H * (Array.isArray(v) ? V(v[0], v[1]) : v ?? d);

// ---- a place + the hero ----
K.fig = (g, t, info, sp) => {
  const p = P01(t, info), cam = camOf(t, info, sp), h = sp.h || {};
  const hxp = E.W * (Array.isArray(h.x) ? V(h.x[0], h.x[1]) : h.x ?? 0.4);
  const place = PL[sp.set || 'room'](g, t, cam, { tod: val(sp.tod ?? 0, p), clockT: val(sp.clock ?? 11 * 3600, p), hx: hxp, phone: sp.dphone, phoneGlow: sp.pg, queue: sp.queue });
  layer(g, cam, 1, (g) => {
    if (sp.duo) drawFigure(g, { x: E.W * 0.64, y: place.GY, s: V(1.6, 1.7), facing: -1, outfit: FRIEND, pose: POSES.talk, expr: 'smile', talk: Math.max(0, Math.sin(t * 9)) * 0.8, rim: { color: place.M.rim, dir: [0, -1], w: 4 } });
    hero(g, t, place.M, place.GY, h);
  });
  if (sp.rays) FX.godRays(g, E.W * 0.5, E.H * 0.35, { t, a: sp.rays, color: place.M.key });
  FX.dust(g, t, { count: 40, color: place.M.key, a: 0.35 });
  if (sp.streak) FX.lensStreak(g, E.W / 2, E.H * 0.3, E.W * 1.2, place.M.key, 0.14);
  overlays(g, t, info, sp);
};

// ---- phone macro insert ----
K.phone = (g, t, info, sp) => {
  blurLayer(g, 14, (g) => PL[sp.bg || 'room'](g, t, { z: 1.6, x: -100, y: -60 }, { tod: sp.tod ?? 0.1 })); veil(g, '#0a0812', 0.55);
  phoneDraw(g, t, info, sp);
  FX.dust(g, t, { count: 28, color: coolC(), a: 0.3 });
  overlays(g, t, info, sp);
};

// ---- giant face lit by the screen ----
K.face = (g, t, info, sp) => {
  const Mw = mood('golden'), r = V(300, 330) * (1 + 0.04 * t), nm = sp.look || 'down';
  const look = nm === 'center' ? [0, 0] : nm === 'scan' ? [0.6 * Math.sin(t * 3), 0.1] : nm === 'side' ? [0.7, 0.1] : [0.05 * Math.sin(t * 2), 0.5 + 0.3 * Math.sin(t * 4)];
  blurLayer(g, 14, (g) => PL[sp.bg || 'room'](g, t, { z: 1.5, x: -120, y: -80 }, { tod: sp.tod ?? 0.2 })); veil(g, '#0a0812', 0.45);
  bigFace(g, E.W / 2, E.H * V(0.62, 0.58), r, { outfit: YOU, expr: sp.expr || 'neutral', look, rimColor: Mw.rim, rimSide: -1, blink: (t % 2.7) > 2.6 });
  glow(g, E.W / 2, E.H * 1.02, 800, coolC(), (sp.glowA ?? 0.28) + 0.1 * Math.sin(t * 9));
  FX.dust(g, t, { count: 26, color: coolC(), a: 0.3 });
  overlays(g, t, info, sp);
};

// ---- giant phone looming over a tiny hero ----
K.loom = (g, t, info, sp) => {
  const M = mood('night'), GY = roomGround();
  g.fillStyle = linGrad(g, 0, 0, 0, E.H, [shade(M.dark, -0.1), M.wall]); g.fillRect(-E.W, -E.H, E.W * 3, E.H * 3);
  phoneDraw(g, t, info, { v: 'feed', speed: 400 }, { cx: E.W * V(0.68, 0.62), cy: E.H * 0.42, pw: V(520, 600), ph: V(980, 1180), rot: 0.06 + 0.01 * Math.sin(t), z: 1 + 0.03 * Math.sin(t * 0.8), glowA: 0.4 });
  g.fillStyle = linGrad(g, 0, GY - 40, 0, E.H, [shade(M.floor, 0.05), M.dark]); g.fillRect(-E.W, GY - 40, E.W * 3, E.H);
  hero(g, t, M, GY, { x: [0.24, 0.3], s: 0.8, pose: sp.pose || 'ready', expr: sp.expr || 'angry' });
  overlays(g, t, info, sp);
};

// ---- chapter card ----
K.num = (g, t, info, sp) => {
  voidBg(g, t); FX.rings(g, E.W / 2, E.H / 2, t, { count: 2, r0: 200, r1: 560, color: GOLD(), a: 0.14 });
  UI.titleCard(g, t, { lines: sp.lines, dur: info.dur, y: E.H * 0.5 });
};

// ---- words that replace each other ----
K.words = (g, t, info, sp) => {
  (sp.bg === 'bp' ? bpBg : voidBg)(g, t);
  const L = sp.lines;
  for (let i = 0; i < L.length; i++) { const at = L[i][1], end = i + 1 < L.length ? L[i + 1][1] : info.dur; if (t >= at && t < end) UI.bigLine(g, t - at, { str: L[i][0], dur: end - at, y: E.H * 0.5, size: V(sp.size ?? 120, (sp.size ?? 120) * 0.8), color: sp.red ? '#e04a3a' : GOLD() }); }
};

// ---- five numbered badges ----
K.five = (g, t, info, sp) => {
  voidBg(g, t);
  const n = 5, gap = V(230, 170), r0 = V(78, 62), y0 = E.H * 0.5, x0 = E.W / 2 - ((n - 1) * gap) / 2;
  const mode = sp.mode || 'seq';
  for (let i = 0; i < n; i++) {
    let a = 1, sc = 1, yo = 0, lit = true;
    if (mode === 'seq') { lit = t > 0.15 + i * (info.dur * 0.75 / n); a = lit ? 1 : 0.3; }
    else if (mode === 'hi') { lit = i !== sp.hi; a = lit ? 0.55 : 1; if (!lit) sc = 1.25 + 0.1 * Math.sin(t * 6); }
    else if (mode === 'pick') { const k = ease.out(prog(t, 0.3, 0.9)); if (i === sp.pick) { sc = 1 + 0.35 * k; yo = -E.H * 0.1 * k; } else a = 1 - 0.65 * k; }
    else if (mode === 'solo') { if (i !== 0) continue; sc = 2.3 + 0.12 * Math.sin(t * 5); }
    const x = mode === 'solo' ? E.W / 2 : x0 + i * gap, y = y0 + yo, r = r0 * sc;
    g.save(); g.globalAlpha *= a; glow(g, x, y, r * 2.4, GOLD(), lit ? 0.35 : 0.1); circle(g, x, y, r, lit ? GOLD() : alpha(CREAM(), 0.25));
    text(g, mode === 'solo' ? '1' : String(i + 1), x, y, { size: r * 1.1, color: lit ? '#1a1220' : CREAM() }); g.restore();
  }
  overlays(g, t, info, sp);
};

K.meter = (g, t, info, sp) => { bpBg(g, t); UI.meter(g, t, { x: E.W * 0.12, y: E.H * 0.5, w: E.W * 0.76, ticks: sp.ticks ?? 40, label: sp.label || 'TIME', start: 0.2, speed: sp.speed ?? 0.5 }); overlays(g, t, info, sp); };

K.counter = (g, t, info, sp) => {
  voidBg(g, t);
  const v = lerp(sp.from, sp.to, ease.inOut(prog(t, 0.1, info.dur * 0.9)));
  text(g, sp.label, E.W / 2, E.H * 0.3, { size: V(60, 52), color: CREAM(), spacing: 4 });
  text(g, v.toFixed(sp.dec ?? 0) + (sp.unit || ''), E.W / 2, E.H * 0.52, { size: V(240, 210), color: GOLD(), glow: 30, glowColor: alpha(GOLD(), 0.6) });
};

K.cards = (g, t, info, sp) => { bpBg(g, t); UI.dataCard(g, t, { title: sp.title, subtitle: sp.sub, from: sp.from, to: sp.to, decimals: sp.dec ?? 0, unit: sp.unit || '', start: 0.3, dur: info.dur * 0.7, total: info.dur, labels: [[1, null]] }); };
K.bars = (g, t, info, sp) => { bpBg(g, t); UI.compareBars(g, t, { rows: sp.rows.map(([label, v]) => ({ label, v })), start: 0.2 }); overlays(g, t, info, sp); };

K.dots = (g, t, info, sp) => {
  voidBg(g, t);
  const cols = 10, gx = V(120, 84), gy = V(110, 100), x0 = E.W / 2 - ((cols - 1) * gx) / 2, y0 = E.H * 0.34; let cnt = 0;
  for (let i = 0; i < 50; i++) { const at = 0.1 + i * (info.dur * 0.5 / 50), p = ease.outBack(clamp((t - at) / 0.2)); if (p <= 0) continue; cnt++; circle(g, x0 + (i % cols) * gx, y0 + Math.floor(i / cols) * gy, V(22, 18) * p, i < cnt ? GOLD() : '#e04a3a'); }
  text(g, 'BUZZES: ' + cnt, E.W / 2, E.H * 0.14, { size: V(66, 56), color: CREAM(), spacing: 3 });
  const a = ease.out(prog(t, info.dur * 0.62, info.dur * 0.82)); if (a > 0) text(g, 'NOT 50 BREAKS', E.W / 2, E.H * 0.88, { size: V(90, 70), color: '#e04a3a', alpha: a, glow: 24, glowColor: 'rgba(224,74,58,.6)' });
};

// ---- small icon scenes ----
K.icon = (g, t, info, sp) => {
  voidBg(g, t); const cx = E.W / 2, cy = E.H * 0.46, a = ease.out(prog(t, 0, 0.4));
  g.save(); g.globalAlpha *= a;
  if (sp.v === 'book') {
    const bw = V(300, 250), bh = V(400, 330); glow(g, cx, cy, bw * 1.8, GOLD(), sp.glow ? 0.4 : 0.12);
    for (const sgn of [-1, 1]) { rr(g, sgn < 0 ? cx - bw : cx + 4, cy - bh / 2, bw - 4, bh, 14); g.fillStyle = CREAM(); g.fill(); for (let i = 0; i < 6; i++) { rr(g, (sgn < 0 ? cx - bw : cx + 4) + 30, cy - bh / 2 + 40 + i * (bh / 8), bw - 64, 10, 5); g.fillStyle = alpha('#14101c', 0.35); g.fill(); } }
    if (sp.label) for (let i = 0; i < 4; i++) { const p = ease.outBack(clamp((t - 0.3 - i * 0.3) / 0.3)); if (p > 0) { rr(g, cx + bw - 6, cy - bh / 2 + 30 + i * 60, 40 * p, 30, 6); g.fillStyle = GOLD(); g.fill(); } }
  } else if (sp.v === 'tv') {
    const tw = V(620, 520), th = V(380, 330); rr(g, cx - tw / 2 - 16, cy - th / 2 - 16, tw + 32, th + 32, 22); g.fillStyle = '#0c0c12'; g.fill();
    rr(g, cx - tw / 2, cy - th / 2, tw, th, 12); g.fillStyle = '#14202c'; g.fill(); g.save(); g.clip();
    for (let i = 0; i < 9; i++) { const yy = cy + th / 2 - ((t * 90 + i * 50) % (9 * 50)); rr(g, cx - tw * (0.1 + 0.12 * (i % 3)), yy, tw * (0.2 + 0.24 * (i % 3)) , 10, 5); g.fillStyle = alpha(CREAM(), 0.6); g.fill(); }
    g.restore(); glow(g, cx, cy, tw, '#7fd0d6', 0.18);
  } else if (sp.v === 'bulb') {
    glow(g, cx, cy - 30, 380, GOLD(), 0.35 + 0.1 * Math.sin(t * 5)); circle(g, cx, cy - 40, V(110, 95), GOLD()); rr(g, cx - 48, cy + 40, 96, 60, 12); g.fillStyle = CREAM(); g.fill();
    for (let i = 0; i < 8; i++) { const an = (i / 8) * Math.PI * 2 + t * 0.5; seg(g, [[cx + Math.cos(an) * 170, cy - 40 + Math.sin(an) * 170], [cx + Math.cos(an) * 220, cy - 40 + Math.sin(an) * 220]], 8, GOLD()); }
    FX.sparkle(g, cx + 120, cy - 150, 40, '#ffffff', 0.9);
  }
  g.restore();
  if (sp.label) text(g, sp.label, cx, E.H * 0.84, { size: V(70, 60), color: CREAM(), spacing: 5, alpha: a });
};

K.week = (g, t, info, sp) => {
  voidBg(g, t); const n = 7, gap = V(200, 138), x0 = E.W / 2 - ((n - 1) * gap) / 2, bw = V(150, 110);
  text(g, 'ONE WEEK', E.W / 2, E.H * 0.26, { size: V(88, 70), color: GOLD(), spacing: 6, glow: 24, glowColor: alpha(GOLD(), 0.5) });
  for (let i = 0; i < n; i++) { const x = x0 + i * gap, y = E.H * 0.52, p = ease.outBack(clamp((t - 0.15 - i * (info.dur * 0.7 / n)) / 0.3));
    rr(g, x - bw / 2, y - bw / 2, bw, bw, 18); g.fillStyle = alpha(CREAM(), 0.14); g.fill(); text(g, 'D' + (i + 1), x, y + bw * 0.72, { size: V(34, 26), color: alpha(CREAM(), 0.7) });
    if (p > 0) seg(g, [[x - bw * 0.22, y], [x - bw * 0.05, y + bw * 0.18 * p], [x + bw * 0.25, y - bw * 0.2 * p]], 10, GOLD()); }
};

K.rooms = (g, t, info, sp) => {
  const GY = roomGround(), M = mood('golden'), Mn = mood('night'), mid = E.W / 2;
  g.fillStyle = linGrad(g, 0, 0, 0, E.H, [M.dark, M.wall]); g.fillRect(0, 0, mid - 14, E.H);
  g.fillStyle = linGrad(g, 0, 0, 0, E.H, [shade(Mn.dark, -0.3), Mn.wall]); g.fillRect(mid + 14, 0, mid, E.H);
  g.fillStyle = shade(M.wall, -0.55); g.fillRect(mid - 14, 0, 28, E.H);
  g.fillStyle = shade(M.floor, 0.05); g.fillRect(0, GY, mid - 14, E.H); g.fillStyle = shade(Mn.floor, -0.2); g.fillRect(mid + 14, GY, mid, E.H);
  hero(g, t, M, GY, { x: [0.25, 0.5], s: 0.9, pose: 'sit', expr: 'smile', prop: undefined });
  const px = E.W * 0.76, py = GY - 14; rr(g, px - 30, py - 8, 60, 8, 3); g.fillStyle = '#0c0c12'; g.fill();
  glow(g, px, py - 10, 140, coolC(), 0.25 + 0.1 * Math.sin(t * 8)); const p = ease.outBack(prog(t, 0.6, 0.9)); if (p > 0) card2(g, px, py - 150 * p, p);
  text(g, 'ANOTHER ROOM', E.W * 0.76, E.H * 0.2, { size: V(56, 40), color: alpha(CREAM(), 0.85), spacing: 4 });
  FX.dust(g, t, { count: 24, color: M.key, a: 0.25 });
};
function card2(g, x, y, p) { g.save(); g.translate(x, y); g.scale(p, p); rr(g, -70, -26, 140, 52, 14); g.fillStyle = alpha(CREAM(), 0.8); g.fill(); circle(g, -44, 0, 12, S().ui.accent); rr(g, -22, -8, 70, 8, 4); g.fillStyle = alpha('#14101c', 0.6); g.fill(); g.restore(); }

K.switch = (g, t, info, sp) => {
  voidBg(g, t); const cx = E.W / 2, cy = E.H * 0.34, flip = ease.out(prog(t, 0.4, 0.55)), rec = ease.in(prog(t, 0.5, info.dur * 0.95));
  glow(g, cx, cy, V(520, 420), GOLD(), 0.55 * rec);
  rr(g, cx - 70, cy - 100, 140, 200, 18); g.fillStyle = CREAM(); g.fill(); rr(g, cx - 22, cy - 62, 44, 124, 14); g.fillStyle = '#9a96aa'; g.fill();
  circle(g, cx, cy + 42 - 84 * flip, 30, '#e04a3a');
  text(g, 'FOCUS', cx, E.H * 0.62, { size: V(62, 52), color: CREAM(), spacing: 4 });
  rr(g, cx - V(360, 300), E.H * 0.7, V(720, 600), 36, 18); g.fillStyle = alpha(CREAM(), 0.14); g.fill();
  rr(g, cx - V(360, 300), E.H * 0.7, V(720, 600) * rec, 36, 18); g.fillStyle = GOLD(); g.fill();
  text(g, 'REBUILDING…', cx, E.H * 0.8, { size: V(40, 32), color: alpha(CREAM(), 0.7), spacing: 3 });
};

K.blocks = (g, t, info, sp) => {
  voidBg(g, t); const cx = E.W / 2, bw = V(300, 240), bh = V(70, 58), base = E.H * 0.78;
  text(g, 'REBUILD IT', cx, E.H * 0.16, { size: V(80, 64), color: GOLD(), spacing: 5 });
  for (let i = 0; i < 8; i++) { const p = ease.outBack(clamp((t - 0.1 - i * (info.dur * 0.75 / 8)) / 0.3)); if (p <= 0) continue; const w = bw * (1 - i * 0.04); g.save(); g.translate(cx + Math.sin(i * 2.1) * 12, base - i * (bh + 6) - bh / 2); g.scale(1, p); rr(g, -w / 2, -bh / 2, w, bh, 10); g.fillStyle = mix(GOLD(), S().ui.accent, i / 8); g.fill(); g.restore(); }
};

K.thread = (g, t, info, sp) => {
  voidBg(g, t); const pts = [], N = 40, x0 = E.W * 0.1, x1 = E.W * 0.9, yc = E.H * 0.5;
  for (let i = 0; i <= N; i++) { const u = i / N; pts.push([lerp(x0, x1, u), yc + Math.sin(u * 9) * V(120, 100) * (1 - 0.2 * u)]); }
  const p = ease.inOut(prog(t, 0.1, info.dur * 0.55)), cut = Math.floor(N * 0.52), gone = ease.out(prog(t, info.dur * 0.5, info.dur * 0.7));
  const a = pts.slice(0, Math.max(2, Math.min(cut, Math.floor(N * p)))); seg(g, a, 10, GOLD());
  if (gone > 0) { const b = pts.slice(cut + 4, cut + 4 + Math.max(2, Math.floor((N - cut - 4) * gone))); if (b.length > 1) seg(g, b, 10, alpha(GOLD(), 0.5)); const c = pts[cut + 2]; FX.sparkle(g, c[0], c[1], 40 * (1 - gone * 0.5), '#ffffff', 0.8); }
  text(g, 'THE THREAD', E.W / 2, E.H * 0.2, { size: V(80, 64), color: CREAM(), spacing: 6 });
};

K.ideas = (g, t, info, sp) => {
  voidBg(g, t); const r = rng(sp.seed ?? 7), pts = []; for (let i = 0; i < 9; i++) pts.push([E.W * (0.15 + 0.7 * r()), E.H * (0.2 + 0.5 * r())]);
  const fade = sp.fade ? 1 - ease.inOut(prog(t, info.dur * 0.3, info.dur * 0.75)) : 1;
  g.save(); g.globalAlpha *= fade;
  for (let i = 0; i < pts.length; i++) { const p = ease.outBack(clamp((t - 0.1 - i * (info.dur * 0.55 / 9)) / 0.3)); if (p <= 0) continue; if (i > 0) seg(g, [pts[i - 1], pts[i]], 4, alpha(GOLD(), 0.6 * p)); circle(g, pts[i][0], pts[i][1], V(20, 16) * p, GOLD()); }
  const c = ease.out(prog(t, info.dur * 0.6, info.dur * 0.85)); if (c > 0 && !sp.fade) FX.sparkle(g, E.W / 2, E.H * 0.45, 90 * c, '#ffffff', 1);
  g.restore();
  if (sp.fade) { const a = ease.inOut(prog(t, info.dur * 0.3, info.dur * 0.8)); glow(g, E.W / 2, E.H * 0.9, 700, coolC(), 0.4 * a); rr(g, E.W / 2 - V(150, 130), E.H * (1.05 - 0.28 * a), V(300, 260), V(520, 460), 36); g.fillStyle = alpha('#0c0c12', 0.95); g.fill(); }
  text(g, sp.fade ? 'GAP FILLED' : 'WHERE IDEAS LIVE', E.W / 2, E.H * 0.12, { size: V(66, 52), color: CREAM(), spacing: 5 });
};

K.slots = (g, t, info, sp) => {
  voidBg(g, t); const cx = E.W / 2, cy = E.H * 0.46, rw = V(190, 150), rh = V(240, 200), gap = rw + 24, stops = [0.4, 0.8, 1.3], res = sp.stop ? [0, 0, 1] : null;
  rr(g, cx - gap * 1.5 - 24, cy - rh / 2 - 60, gap * 3 + 24, rh + 120, 28); g.fillStyle = shade(GOLD(), -0.2); g.fill();
  seg(g, [[cx + gap * 1.5 + 40, cy - 40], [cx + gap * 1.5 + 90, cy - 150 + 60 * Math.max(0, Math.sin(t * 4))]], 12, '#c0c0d0'); circle(g, cx + gap * 1.5 + 90, cy - 150 + 60 * Math.max(0, Math.sin(t * 4)), 28, '#e04a3a');
  for (let i = 0; i < 3; i++) {
    const x = cx + (i - 1) * gap; rr(g, x - rw / 2, cy - rh / 2, rw, rh, 14); g.fillStyle = CREAM(); g.fill(); g.save(); g.clip();
    const stopped = !!sp.stop && t > stops[i], step = rh * 0.8, raw = t * 900 + i * 133, off = stopped ? 0 : raw % step, base = stopped ? res[i] : Math.floor(raw / step);
    for (let k = -1; k <= 1; k++) circle(g, x, cy + k * step + off, rw * 0.28, [S().ui.accent, '#3fb970', '#8a7fd6'][(((base + k) % 3) + 3) % 3]);
    g.restore();
  }
  if (sp.stop && t > stops[2] + 0.2) text(g, 'ALMOST…', cx, E.H * 0.84, { size: V(80, 62), color: '#e04a3a', glow: 24, glowColor: 'rgba(224,74,58,.6)' });
};

K.doors = (g, t, info, sp) => {
  const M = mood('night'), GY = roomGround(); g.fillStyle = linGrad(g, 0, 0, 0, GY, [shade(M.dark, -0.1), M.wall]); g.fillRect(-E.W, -E.H, E.W * 3, GY + E.H);
  g.fillStyle = linGrad(g, 0, GY - 40, 0, E.H, [shade(M.floor, 0.05), M.dark]); g.fillRect(-E.W, GY - 40, E.W * 3, E.H); FX.floorLines(g, GY - 40, E.H, 'rgba(0,0,0,.2)', 0.07);
  const dw = V(130, 110), gap = V(520, 380), sp2 = V(260, 200), tot = gap * 5;
  for (let i = 0; i < 5; i++) { const x = ((E.W + i * gap - t * sp2) % tot + tot) % tot - gap * 0.5; FX.door(g, { x, y: GY, w: dw, h: V(300, 280), color: shade(M.wall, 0.1), open: 0.25, light: coolC() }); }
  hero(g, t, M, GY, { x: [0.3, 0.45], pose: [[0, 'phone']], prop: 'phone', expr: 'neutral' });
  overlays(g, t, info, sp);
};

K.screenclose = (g, t, info, sp) => {
  voidBg(g, t); const w = V(1180, 900), h = V(620, 640), x = (E.W - w) / 2, y = E.H * 0.2;
  FX.screen(g, { x, y, w, h, bg: '#16212c', glowC: coolC(), a: 0.2 }, (g, x, y, w, h) => {
    const pulses = [0.3, 1.1, 1.9]; let c = 0;
    for (const q of pulses) if (t > q) c++;
    for (let i = 0; i < 9; i++) { rr(g, x + 40, y + 40 + i * (h - 80) / 9, (w - 80) * (0.55 + 0.4 * ((i * 53) % 10) / 10), 18, 8); g.fillStyle = alpha('#e8f0ff', 0.28); g.fill(); }
    let hl = 0; for (const q of pulses) hl = Math.max(hl, Math.max(0, 1 - Math.abs(t - q - 0.2) / 0.35));
    rr(g, x + 30, y + 40 + 4 * (h - 80) / 9 - 10, w - 60, 38, 10); g.fillStyle = alpha(GOLD(), 0.15 + 0.5 * hl); g.fill();
    if (c) text(g, '×' + c, x + w - 80, y + 40 + 4 * (h - 80) / 9 + 8, { size: V(50, 44), color: GOLD() });
  });
  text(g, 'READ IT AGAIN', E.W / 2, E.H * 0.9, { size: V(60, 48), color: CREAM(), spacing: 4 });
};

K.end = (g, t, info, sp) => { UI.endScreen(g, t, { question: sp.q, cast: [YOU] }); };

for (const id of Object.keys(SPECS)) { const sp = SPECS[id]; registerShot(id, { draw(g, t, info) { K[sp.k](g, t, info, sp); } }); }
