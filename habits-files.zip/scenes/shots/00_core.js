// shots/00_core.js — shared helpers for the 5 phone habits video (figures, scene runner, overlays, phone).
import { E, V, mood, layer, blurLayer, veil, ease, prog, S, rr, seg, circle, glow, alpha, shade, mix, linGrad, text, clamp, lerp } from '/engine/core.js';
import { drawFigure, POSES, posesAt, breathe, bigFace, headPos } from '/engine/rig2d.js';
import * as FX from '/engine/fx2d.js';
import * as UI from '/engine/ui2d.js';
import { room, roomGround } from '../sets/room.js';
import { bedroom, kitchen, street, desk } from '../sets/places.js';
import { YOU, FRIEND } from '../cast.js';

export const PL = { room, bedroom, kitchen, street, desk };
export const val = (v, p) => (Array.isArray(v) ? lerp(v[0], v[1], p) : v);
export const P01 = (t, info) => ease.inOut(clamp(t / info.dur));
export const camOf = (t, info, sp) => { const k = P01(t, info); return { z: lerp(sp.z0 ?? 1, sp.z1 ?? 1.06, k), x: lerp(sp.x0 ?? 0, sp.x1 ?? 0, k), y: lerp(sp.y0 ?? 0, sp.y1 ?? 0, k) }; };
export const coolC = () => mood('interiorCool').practical;
export const poseOf = (t, p) => (Array.isArray(p) ? posesAt(t, p) : POSES[p ?? 'stand'] || POSES.stand);

// bg for abstract shots
export function voidBg(g, t, sp = {}) {
  const M = mood('void');
  g.fillStyle = linGrad(g, 0, 0, 0, E.H, [shade(M.dark, -0.2), M.wall]); g.fillRect(-E.W, -E.H, E.W * 3, E.H * 3);
  FX.dust(g, t, { count: 34, color: S().ui.gold, a: 0.22 });
}
export function bpBg(g, t) { UI.blueprint(g, {}); }

// the hero figure (+ screen glow when holding the phone)
export function hero(g, t, M, GY, h = {}) {
  const s = (h.s ?? 1) * V(1.6, 1.7), x = E.W * (Array.isArray(h.x) ? V(h.x[0], h.x[1]) : h.x ?? 0.4), pose = breathe(poseOf(t, h.pose), t), facing = h.facing ?? 1;
  const base = { x, y: GY, s, facing, outfit: h.outfit ?? YOU, pose, expr: h.expr ?? 'neutral', rim: { color: M.rim, dir: [0, -1], w: 4 }, blink: (t % 3.3) > 3.2 };
  if (h.prop) base.prop = h.prop;
  if (h.talk) base.talk = Math.max(0, Math.sin(t * 9)) * 0.8;
  if (h.ghost) for (let i = 3; i >= 1; i--) drawFigure(g, { ...base, x: x - i * 70 * s * 0.5, alpha: 0.16 / i * 1.6 });
  drawFigure(g, base);
  if (h.prop === 'phone') { const [hx, hy] = headPos({ x, y: GY, s, facing, outfit: base.outfit, pose }); glow(g, hx + 24 * s * facing, hy + 18 * s, 150 * s, coolC(), 0.22 + 0.18 * (h.glow ?? 0)); }
  return { x, s };
}

// overlays that can sit on top of any shot
export const OV = {
  readout: (g, t, info, o) => UI.readout(g, { label: o.label, value: o.value, x: E.W * (Array.isArray(o.x) ? V(o.x[0], o.x[1]) : o.x ?? 0.62), y: E.H * (Array.isArray(o.y) ? V(o.y[0], o.y[1]) : o.y ?? 0.3), a: ease.out(prog(t, o.at ?? 0.3, (o.at ?? 0.3) + 0.3)) }),
  line: (g, t, info, o) => { const at = o.at ?? 0; if (t >= at) UI.bigLine(g, t - at, { str: o.str, dur: (o.dur ?? info.dur) - at, y: E.H * (Array.isArray(o.y) ? V(o.y[0], o.y[1]) : o.y ?? 0.2), size: V(o.size ?? 72, (o.size ?? 72) * 0.85) }); },
  title: (g, t, info, o) => UI.titleCard(g, t, { lines: o.lines, dur: info.dur, y: E.H * (Array.isArray(o.y) ? V(o.y[0], o.y[1]) : o.y ?? 0.4) }),
  rings: (g, t, info, o) => FX.rings(g, E.W * (o.x ?? 0.5), E.H * (o.y ?? 0.4), t, { count: 3, r0: 40, r1: o.r ?? 150, color: o.color ?? S().ui.gold, a: 0.45, speed: o.speed ?? 0.9 }),
  bubble: (g, t, info, o) => { const a = ease.outBack(prog(t, o.at ?? 0.2, (o.at ?? 0.2) + 0.3)); if (a > 0) UI.bubble(g, E.W * (o.x ?? 0.45), E.H * (o.y ?? 0.2), { w: V(150, 150) * a, h: V(84, 84) * a, dots: true }); },
  meter: (g, t, info, o) => UI.meter(g, t, { x: E.W * 0.12, y: E.H * (o.y ?? 0.88), w: E.W * 0.76, ticks: o.ticks ?? 36, label: o.label ?? 'FOCUS', start: o.at ?? 0.3, speed: o.speed ?? 0.4 }),
};
export const overlays = (g, t, info, sp) => { for (const o of sp.ov || []) OV[o.k](g, t, info, o); };

// ---------- phone ----------
const PAL = () => [S().ui.accent, S().ui.gold, '#7fd0d6', '#d6577f', '#8a7fd6'];
function card(g, x, y, w, h) {
  rr(g, x, y, w, h, 22); g.fillStyle = alpha(S().ui.cream, 0.92); g.fill();
  circle(g, x + h * 0.5, y + h / 2, h * 0.26, S().ui.accent);
  rr(g, x + h * 0.95, y + h * 0.3, w * 0.5, h * 0.14, 6); g.fillStyle = alpha('#14101c', 0.7); g.fill();
  rr(g, x + h * 0.95, y + h * 0.56, w * 0.32, h * 0.12, 6); g.fillStyle = alpha('#14101c', 0.4); g.fill();
}
function post(g, x, y, w, h, i) {
  rr(g, x, y, w, h, 18); g.fillStyle = alpha(S().ui.cream, 0.9); g.fill();
  circle(g, x + 34, y + 36, 18, PAL()[((i % 5) + 5) % 5]);
  rr(g, x + 66, y + 24, w * 0.4, 10, 5); g.fillStyle = alpha('#14101c', 0.6); g.fill();
  rr(g, x + 14, y + 66, w - 28, h - 84, 12); g.fillStyle = alpha(PAL()[(((i * 3) % 5) + 5) % 5], 0.85); g.fill();
  circle(g, x + w * (0.3 + 0.4 * (((i * 7) % 10) / 10)), y + 66 + (h - 84) / 2, (h - 84) * 0.22, alpha('#ffffff', 0.35));
}
const CONTENT = {
  notifs(g, t, x, y, w, h, sp) {
    const n = sp.n ?? 3, gap = sp.gap ?? 0.35, ch = h * 0.15;
    for (let i = 0; i < n; i++) {
      const at = 0.1 + i * gap, p = ease.outBack(clamp((t - at) / 0.35)); if (p <= 0) continue;
      const jit = sp.shake ? Math.sin(t * 40 + i) * 3 * (1 - clamp((t - at) / 0.3)) : 0;
      g.save(); g.translate(x + w / 2 + jit, y + 56 + i * (ch + 22) + ch / 2); g.scale(p, p); card(g, -(w - 56) / 2, -ch / 2, w - 56, ch); g.restore();
    }
  },
  flood(g, t, x, y, w, h) {
    const ch = h * 0.13, off = Math.max(0, t - 0.9) * 150;
    for (let i = 0; i < 12; i++) {
      const p = ease.outBack(clamp((t - (0.05 + i * 0.16)) / 0.3)); if (p <= 0) continue;
      g.save(); g.translate(x + w / 2, y + 50 + i * (ch + 14) + ch / 2 - off); g.scale(p, p); card(g, -(w - 48) / 2, -ch / 2, w - 48, ch); g.restore();
    }
  },
  feed(g, t, x, y, w, h, sp) {
    const ph = h * 0.5, off = t * (sp.speed ?? 520) * (sp.slow ? 1 - 0.8 * clamp(t / 2) : 1), i0 = Math.floor(off / ph);
    for (let k = -1; k < 3; k++) post(g, x + 14, y + k * ph - (off % ph) + 10, w - 28, ph - 14, i0 + k);
  },
  refresh(g, t, x, y, w, h, sp) {
    CONTENT.feed(g, t * 0.25, x, y + 70 * Math.sin(clamp(t / 1.2) * Math.PI * 0.5), w, h, { speed: 260 });
    g.save(); g.translate(x + w / 2, y + 40); g.rotate(t * 7); g.strokeStyle = S().ui.gold; g.lineWidth = 7; g.lineCap = 'round'; g.beginPath(); g.arc(0, 0, 20, 0, Math.PI * 1.5); g.stroke(); g.restore();
    if (t > (sp.at ?? 1.6)) FX.sparkle(g, x + w / 2, y + h * 0.5, 50 * ease.outBack(clamp((t - (sp.at ?? 1.6)) / 0.4)), S().ui.gold, 0.9);
  },
  toggles(g, t, x, y, w, h, sp) {
    const n = 5, rh = h / 7.5, keep = sp.keep ?? 2;
    for (let i = 0; i < n; i++) {
      const cy = y + 70 + i * rh + rh / 2, on = i === keep ? true : t < 0.5 + i * 0.5, k = i === keep ? 1 : ease.out(clamp((t - (0.5 + i * 0.5)) / 0.2));
      rr(g, x + 20, cy - rh * 0.38, w - 40, rh * 0.76, 16); g.fillStyle = alpha(S().ui.cream, 0.14); g.fill();
      if (i === keep) { circle(g, x + 62, cy - 8, 12, S().ui.gold); rr(g, x + 42, cy + 8, 40, 20, 10); g.fillStyle = S().ui.gold; g.fill(); } else circle(g, x + 62, cy, 20, alpha(PAL()[i % 5], on ? 0.9 : 0.35));
      rr(g, x + 100, cy - 6, w * 0.3, 12, 6); g.fillStyle = alpha(S().ui.cream, 0.5); g.fill();
      const tw = 74, th = 38, tx = x + w - tw - 40; rr(g, tx, cy - th / 2, tw, th, th / 2); g.fillStyle = on ? S().ui.accent : alpha('#8a8a99', 0.6); g.fill();
      circle(g, tx + (i === keep ? tw - th / 2 : lerp(tw - th / 2, th / 2, k)), cy, th * 0.4, '#ffffff');
    }
  },
  timer(g, t, x, y, w, h, sp) {
    const p = clamp(t / (sp.dur ?? 2.5)), cx = x + w / 2, cy = y + h * 0.42, r = w * 0.3;
    g.lineWidth = 20; g.lineCap = 'round'; g.strokeStyle = alpha(S().ui.cream, 0.15); g.beginPath(); g.arc(cx, cy, r, 0, Math.PI * 2); g.stroke();
    g.strokeStyle = S().ui.gold; g.beginPath(); g.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + (1 - p * 0.6) * Math.PI * 2); g.stroke();
    const rem = Math.round(900 * (1 - p * 0.6)); text(g, String(Math.floor(rem / 60)).padStart(2, '0') + ':' + String(rem % 60).padStart(2, '0'), cx, cy, { size: V(70, 70), color: S().ui.cream });
    rr(g, cx - w * 0.22, y + h * 0.78, w * 0.44, 56, 28); g.fillStyle = S().ui.accent; g.fill();
  },
  home(g, t, x, y, w, h, sp) {
    const cols = 4, cell = (w - 40) / cols, at = sp.at ?? 0.5, mv = ease.inOut(clamp((t - at) / 0.9));
    for (let i = 0; i < 20; i++) {
      const c = i % cols, r = Math.floor(i / cols), ix = x + 20 + c * cell + cell / 2, iy = y + 60 + r * (cell * 1.1) + cell / 2;
      if (i === 9) { const tx = x + w / 2, ty = y + h - 80; g.save(); g.translate(lerp(ix, tx, mv), lerp(iy, ty, mv)); g.scale(1 - 0.25 * mv, 1 - 0.25 * mv); rr(g, -cell * 0.36, -cell * 0.36, cell * 0.72, cell * 0.72, 16); g.fillStyle = S().ui.accent; g.fill(); g.restore(); continue; }
      rr(g, ix - cell * 0.36, iy - cell * 0.36, cell * 0.72, cell * 0.72, 16); g.fillStyle = alpha(PAL()[i % 5], 0.8); g.fill();
    }
    rr(g, x + w / 2 - cell * 0.5, y + h - 80 - cell * 0.5, cell, cell, 20); g.strokeStyle = alpha(S().ui.cream, 0.5); g.lineWidth = 4; g.stroke();
  },
  contacts(g, t, x, y, w, h) {
    for (let i = 0; i < 3; i++) { const p = ease.out(clamp((t - 0.1 - i * 0.3) / 0.3)); const cy = y + 100 + i * h * 0.2; if (p <= 0) continue;
      g.save(); g.globalAlpha *= p; circle(g, x + 70, cy, 36, PAL()[(i * 2) % 5]); rr(g, x + 130, cy - 14, w * 0.4, 12, 6); g.fillStyle = alpha(S().ui.cream, 0.7); g.fill(); rr(g, x + 130, cy + 8, w * 0.25, 10, 5); g.fillStyle = alpha(S().ui.cream, 0.35); g.fill(); g.restore(); }
    const pc = 1 + 0.08 * Math.sin(t * 6); circle(g, x + w / 2, y + h - 110, 46 * pc, '#3fb970'); glow(g, x + w / 2, y + h - 110, 120, '#3fb970', 0.3);
  },
  quiet(g, t, x, y, w, h) {
    const cx = x + w / 2, cy = y + h * 0.4; circle(g, cx, cy, 70, '#e8ecff'); circle(g, cx + 32, cy - 20, 62, shade(mood('interiorCool').wall, 0.05));
    text(g, 'QUIET', cx, y + h * 0.66, { size: V(54, 54), color: alpha(S().ui.cream, 0.8), spacing: 4 });
  },
  lock(g, t, x, y, w, h) {
    text(g, '9:41', x + w / 2, y + h * 0.26, { size: V(130, 130), color: S().ui.cream });
    rr(g, x + w * 0.3, y + h * 0.36, w * 0.4, 12, 6); g.fillStyle = alpha(S().ui.cream, 0.4); g.fill();
    g.save(); g.globalAlpha *= 0.5; card(g, x + 28, y + h * 0.7, w - 56, h * 0.13); g.restore();
  },
};
export function phoneDraw(g, t, info, sp, o = {}) {
  const Mc = mood('interiorCool'), cx = o.cx ?? E.W / 2, cy = o.cy ?? E.H * 0.52, pw = o.pw ?? V(360, 520), ph = o.ph ?? V(640, 900), z = o.z ?? 1 + 0.06 * P01(t, info);
  glow(g, cx, cy, Math.max(pw, ph) * 0.95, Mc.practical, o.glowA ?? 0.3);
  g.save(); g.translate(cx, cy); g.rotate(o.rot ?? (-0.08 + 0.02 * Math.sin(t * 1.5))); g.scale(z, z);
  rr(g, -pw / 2, -ph / 2, pw, ph, 46); g.fillStyle = '#0c0c12'; g.fill();
  const sx = -pw / 2 + 14, sy = -ph / 2 + 14, sw = pw - 28, sh = ph - 28;
  rr(g, sx, sy, sw, sh, 34); g.fillStyle = shade(Mc.wall, 0.05); g.fill(); g.clip();
  (CONTENT[sp.v] || CONTENT.notifs)(g, t, sx, sy, sw, sh, { ...sp, dur: info.dur });
  g.restore();
}
