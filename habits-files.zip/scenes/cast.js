// cast.js — recurring characters. Signature colours stay identical in every shot.
export const YOU = { top: 'hoodie', color: '#d64a33', head: 'none' };          // "you", the viewer
export const FRIEND = { top: 'tshirt', color: '#3a6ea5', head: 'ponytail' };     // someone talking to you
export const EXTRAS = [                                                          // background people, all staring at phones
  { top: 'tshirt', color: '#7a6bb0', head: 'beanie' }, { top: 'hoodie', color: '#4a8f7a', head: 'cap' },
  { top: 'jersey', color: '#b0884a', head: 'curly' }, { top: 'tshirt', color: '#8a4a6a', head: 'bun' },
  { top: 'hoodie', color: '#5a7ab0', head: 'spiky' },
];
export const CAST = [YOU, FRIEND];
