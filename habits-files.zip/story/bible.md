# Bible — "5 Phone Habits Stealing Your Hours" (full cut, ~5:27)
Logline: second-person explainer. "You" are losing hours ten seconds at a time to a phone; five habits, five fixes, then the reveal that every habit was automatic, not a choice.
Tone: calm, a little uneasy, then warm and hopeful. Emerald style (deep green shadows, gold key light).
## Cast
| id | role | outfit | expressions used |
|---|---|---|---|
| YOU | the viewer / hero | red-orange hoodie #d64a33, no hat | neutral, smile, thinking, scared, angry |
| FRIEND | talks to you in one shot | blue tee, ponytail | smile |
| extras | queue of people staring at phones | mixed colours | neutral |
## Sets
room (golden hour to night), bedroom (morning), kitchen (kettle), street queue, desk with laptop.
## Structure
Intro hook 0-12.8 | setup 12.8-40 | habit 1 morning reach 40-78 | habit 2 notifications 78-122 | habit 3 reflex check 122-165 | habit 4 endless scroll 165-206 | habit 5 phone within reach 206-243 | reveal + "picture tomorrow" 243-285 | the hour maths 285-301 | call to action 302-end.
