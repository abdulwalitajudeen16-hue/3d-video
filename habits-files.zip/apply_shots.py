# apply_shots.py — merges the real audio duration into my_shots.json and installs it as story/shots.json.
import json, os, sys, glob
proj = sys.argv[1] if len(sys.argv) > 1 else '.'
sp = os.path.join(proj, 'story', 'shots.json'); mine = json.load(open(os.path.join(proj, 'story', 'my_shots.json')))
dur = None
if os.path.exists(sp):
    try:
        d = json.load(open(sp)); dur = d.get('duration') or max(s['end'] for s in d['shots'])
        os.replace(sp, os.path.join(proj, 'story', 'shots_draft.json'))
    except Exception as e: print('could not read the draft shot list:', e)
if not dur or dur < mine['shots'][-1]['start'] + 1: dur = mine['duration']; print('using fallback duration', dur)
mine['duration'] = round(float(dur), 2); mine['shots'][-1]['end'] = mine['duration']
if mine['music']: mine['music'][-1]['end'] = mine['duration']
json.dump(mine, open(sp, 'w'), indent=1)
keep = {'00_core.js', '10_kinds.js', '20_specs.js'}; d = os.path.join(proj, 'scenes', 'shots')
for f in glob.glob(os.path.join(d, '*.js')):
    if os.path.basename(f) not in keep: os.remove(f); print('removed old scene file', os.path.basename(f))
print('ready:', len(mine['shots']), 'shots,', mine['duration'], 's')
