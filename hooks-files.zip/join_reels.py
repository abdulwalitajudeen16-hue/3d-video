# join_reels.py — cut each hook out of the hooks video and put it in front of the body of Trial_1.
# usage: python3 join_reels.py HOOKS_VIDEO BODY_VIDEO OUT_DIR
import subprocess, sys, os
hooks, body, outdir = sys.argv[1], sys.argv[2], sys.argv[3]
BODY_START = 7.84   # where the body begins in the Trial_1 video
TAIL = 0.30         # a little breathing room after each hook
HOOKS = [  # (reel number, start, end) in the hooks video
 (2, 0.00, 4.72), (3, 5.42, 8.08), (4, 8.80, 12.32), (5, 13.12, 15.66), (6, 16.40, 19.58),
 (7, 20.18, 22.90), (8, 23.96, 27.50), (9, 28.34, 32.56), (10, 33.18, 37.30),
]
os.makedirs(outdir, exist_ok=True)
AF = 'aformat=sample_rates=48000:channel_layouts=stereo'
VF = 'fps=24,format=yuv420p,setsar=1'
for n, s, e in HOOKS:
    out = os.path.join(outdir, 'Trial_%02d.mp4' % n)
    fc = f'[0:v:0]{VF}[v0];[0:a:0]{AF}[a0];[1:v:0]{VF}[v1];[1:a:0]{AF}[a1];[v0][a0][v1][a1]concat=n=2:v=1:a=1[v][a]'
    cmd = ['ffmpeg', '-nostdin', '-loglevel', 'error', '-y', '-ss', str(s), '-to', str(e + TAIL), '-i', hooks, '-ss', str(BODY_START), '-i', body,
           '-filter_complex', fc, '-map', '[v]', '-map', '[a]', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-c:a', 'aac', '-b:a', '160k', out]
    r = subprocess.run(cmd); print('made' if r.returncode == 0 else 'FAILED', out)
