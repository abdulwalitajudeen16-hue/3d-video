// shots/01_phone.js — "5 Phone Habits Stealing Your Hours" (14 s test): room, phone insert, giant face, time-lapse, title.
import { E, V, registerShot, mood, layer, blurLayer, veil, ease, prog, wordTime, S, rr, circle, glow, alpha, shade } from '/engine/core.js';
import { drawFigure, POSES, posesAt, breathe, bigFace, headPos } from '/engine/rig2d.js';
import * as FX from '/engine/fx2d.js';
import * as UI from '/engine/ui2d.js';
import { room, roomGround } from '../sets/room.js';
import { YOU } from '../cast.js';

const FS = () => V(1.6, 1.7);                                   // medium-shot figure scale
const heroX = () => E.W / 2 - V(180, 120);
const rimOf = (M) => ({ color: M.rim, dir: [0, -1], w: 4 });

// hero standing with the phone, lit from behind by the window and from the front by the screen
function hero(g, t, M, o = {}) {
  const GY = roomGround(), s = o.s ?? FS(), x = o.x ?? heroX(), tod = o.tod ?? 0;
  const pose = breathe(o.pose ?? POSES.phone, t);
  drawFigure(g, { x, y: GY, s, facing: 1, outfit: YOU, pose, expr: o.expr ?? 'neutral', prop: o.prop === false ? undefined : 'phone', rim: rimOf(M), blink: (t % 3.3) > 3.2 });
  const [hx, hy] = headPos({ x, y: GY, s, facing: 1, outfit: YOU, pose });
  glow(g, hx + 24 * s, hy + 18 * s, 150 * s, mood('interiorCool').practical, 0.18 + 0.22 * tod);
}

// s001 — "You didn't lose your day in one big moment."  establishing wide, slow push, golden hour
registerShot('s001', { draw(g, t, info) {
  const k = ease.inOut(t / info.dur), cam = { z: 1 + 0.08 * k, x: -30 * k };
  const { M, win } = room(g, t, cam, { tod: 0 });
  layer(g, cam, 1, (g) => hero(g, t, M, { s: V(1.05, 1.2), pose: POSES.stand, prop: false }));
  FX.godRays(g, win.x + win.w / 2, win.y + win.h * 0.5, { t, a: 0.09, color: M.key });
  FX.dust(g, t, { count: 45, color: M.key, a: 0.4 });
  FX.lensStreak(g, E.W / 2, E.H * 0.3, E.W * 1.2, M.key, 0.15);
} });

// s002 — "You lost it 10 seconds at a time."  medium, phone up, "EVERY 10 s" pops on the word
registerShot('s002', { draw(g, t, info) {
  const k = ease.inOut(t / info.dur), cam = { z: 1.05 + 0.1 * k, x: -20 * k };
  const { M } = room(g, t, cam, { tod: 0.05 });
  layer(g, cam, 1, (g) => hero(g, t, M, { pose: posesAt(t, [[0, 'stand'], [0.5, 'phone']]), expr: t > 1.4 ? 'sleepy' : 'neutral' }));
  FX.dust(g, t, { count: 40, color: M.key, a: 0.35 });
  const w = (wordTime('10', info.shot.start) ?? info.shot.start + 0.8) - info.shot.start;
  UI.readout(g, { label: 'EVERY', value: '10 s', x: E.W * 0.7, y: E.H * V(0.3, 0.2), a: ease.out(prog(t, w, w + 0.3)) });
} });

// s003 — "A quick check,"  macro insert: the phone with notification cards popping in
registerShot('s003', { draw(g, t, info) {
  const Mc = mood('interiorCool');
  blurLayer(g, 14, (g) => room(g, t, { z: 1.6, x: -100, y: -60 }, { tod: 0.1 })); veil(g, '#0a0812', 0.55);
  const cx = E.W / 2, cy = E.H * 0.52, pw = V(360, 520), ph = V(640, 900), z = 1 + 0.06 * ease.inOut(t / info.dur);
  glow(g, cx, cy, 650, Mc.practical, 0.3);
  g.save(); g.translate(cx, cy); g.rotate(-0.08 + 0.02 * Math.sin(t * 1.5)); g.scale(z, z);
  rr(g, -pw / 2, -ph / 2, pw, ph, 46); g.fillStyle = '#0c0c12'; g.fill();
  rr(g, -pw / 2 + 14, -ph / 2 + 14, pw - 28, ph - 28, 34); g.fillStyle = shade(Mc.wall, 0.05); g.fill();
  for (let i = 0; i < 3; i++) {
    const p = ease.outBack((t - (0.1 + i * 0.35)) / 0.35); if (p <= 0) continue;
    const cw = pw - 70, ch = ph * 0.15, y = -ph / 2 + 70 + i * (ch + 22);
    g.save(); g.translate(0, y + ch / 2); g.scale(p, p);
    rr(g, -cw / 2, -ch / 2, cw, ch, 22); g.fillStyle = alpha(S().ui.cream, 0.92); g.fill();
    circle(g, -cw / 2 + ch * 0.5, 0, ch * 0.26, S().ui.accent);
    rr(g, -cw / 2 + ch * 0.95, -ch * 0.2, cw * 0.5, ch * 0.14, 6); g.fillStyle = alpha(Mc.dark, 0.7); g.fill();
    rr(g, -cw / 2 + ch * 0.95, ch * 0.05, cw * 0.32, ch * 0.12, 6); g.fillStyle = alpha(Mc.dark, 0.4); g.fill();
    g.restore();
  }
  g.restore();
  FX.dust(g, t, { count: 30, color: Mc.practical, a: 0.3 });
} });

// s004 — "a quick scroll, a quick look,"  giant face lit by the screen, eyes drift down, then sleepy
registerShot('s004', { draw(g, t, info) {
  const Mc = mood('interiorCool'), Mw = mood('golden');
  blurLayer(g, 14, (g) => room(g, t, { z: 1.5, x: -120, y: -80 }, { tod: 0.2 })); veil(g, '#0a0812', 0.45);
  const r = V(300, 330) * (1 + 0.04 * t);
  bigFace(g, E.W / 2, E.H * V(0.62, 0.58), r, { outfit: YOU, expr: t > 1.0 ? 'sleepy' : 'neutral', look: [0.05 * Math.sin(t * 2), 0.5 + 0.3 * Math.sin(t * 4)], rimColor: Mw.rim, rimSide: -1, blink: (t % 2.7) > 2.6 });
  glow(g, E.W / 2, E.H * 1.02, 800, Mc.practical, 0.28 + 0.1 * Math.sin(t * 9));
  FX.dust(g, t, { count: 30, color: Mc.practical, a: 0.3 });
} });

// s005 — "and somewhere between those quick looks,"  time-lapse: sky goes golden -> night, clock races
registerShot('s005', { draw(g, t, info) {
  const p = ease.inOut(t / info.dur), cam = { z: 1.12 - 0.12 * p, x: -10 };
  const { M } = room(g, t, cam, { tod: p, clockT: 3600 * (2 + 8 * p) });
  layer(g, cam, 1, (g) => hero(g, t, M, { pose: POSES.phone, expr: 'sleepy', tod: p }));
  FX.dust(g, t, { count: 40, color: M.key, a: 0.35 });
  FX.lensStreak(g, E.W / 2, E.H * 0.3, E.W * 1.2, M.key, 0.12);
} });

// s006 — "your hours disappeared."  night room, glowing phone face, title card
registerShot('s006', { draw(g, t, info) {
  const k = ease.inOut(t / info.dur), cam = { z: 1 + 0.06 * k, x: 20 * k };
  const { M } = room(g, t, cam, { tod: 1, clockT: 3600 * 10 });
  layer(g, cam, 1, (g) => hero(g, t, M, { x: V(E.W * 0.22, E.W * 0.5), s: V(1.25, 1.35), pose: POSES.phone, expr: 'sleepy', tod: 1 }));
  veil(g, '#05030a', 0.25);
  FX.dust(g, t, { count: 30, color: mood('interiorCool').practical, a: 0.25 });
  UI.titleCard(g, t, { lines: ['5 PHONE HABITS', 'STEALING YOUR HOURS'], dur: info.dur, y: E.H * V(0.4, 0.3) });
} });
