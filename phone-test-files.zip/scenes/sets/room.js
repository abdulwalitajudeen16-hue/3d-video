// sets/room.js — living room: big window (golden hour -> night), wall clock, sofa, floor lamp.
// o.tod: 0 = golden hour, 1 = night.  o.clockT: seconds shown on the wall clock.
import { E, V, mood, layer, rr, seg, circle, linGrad, glow, alpha, shade, mix } from '/engine/core.js';
import * as FX from '/engine/fx2d.js';

export const roomGround = () => E.H * V(0.8, 0.68);
export function room(g, t, cam, o = {}) {
  const tod = Math.max(0, Math.min(1, o.tod ?? 0));
  const Mg = mood('golden'), Mn = mood('night');
  const M = {
    sky: Mg.sky.map((c, i) => mix(c, Mn.sky[i] ?? Mn.sky[Mn.sky.length - 1], tod)),
    wall: mix(Mg.wall, Mn.wall, tod), floor: mix(Mg.floor, Mn.floor, tod), dark: mix(Mg.dark, Mn.dark, tod),
    key: mix(Mg.key, Mn.key, tod), rim: mix(Mg.rim, Mn.rim, tod), practical: Mg.practical,
  };
  const GY = roomGround(), CX = E.W / 2;
  const wx = CX - V(330, 300), wy = GY - V(560, 760), ww = V(660, 600), wh = V(330, 420);
  layer(g, cam, 0.35, (g) => {
    g.fillStyle = linGrad(g, 0, -E.H, 0, GY, [M.dark, M.wall]); g.fillRect(-E.W, -E.H, E.W * 3, GY + E.H);
    FX.windowFrame(g, { x: wx, y: wy, w: ww, h: wh, cols: 3, frame: shade(M.wall, -0.55), bar: 10 }, (g, x, y, w, h) => {
      g.fillStyle = linGrad(g, 0, y, 0, y + h, M.sky); g.fillRect(x, y, w, h);
      if (tod < 0.85) { g.save(); g.globalAlpha = 1 - tod; FX.sun(g, x + w * 0.5, y + h * (0.55 + 0.5 * tod), 55, '#fff7e6', Mg.key, 4); g.restore(); }
      if (tod > 0.35) { g.save(); g.globalAlpha = (tod - 0.35) / 0.65; FX.stars(g, t, { area: [x, y, w, h * 0.55], count: 45 }); g.restore(); }
      FX.skyline(g, { x, y: y + h, w, maxH: h * 0.6, color: alpha(shade(M.wall, -0.2), 0.8), windowColor: alpha(M.practical, 0.3 + 0.55 * tod), seed: 4 });
    });
    FX.clock(g, CX + V(560, 330), GY - V(600, 1100), 34, o.clockT ?? 11 * 3600, { face: '#e9e2ea' });
  });
  layer(g, cam, 0.8, (g) => {
    rr(g, CX + V(260, 150), GY - V(150, 170), V(520, 420), V(150, 170), 34); g.fillStyle = shade(M.wall, -0.38); g.fill();
    rr(g, CX + V(250, 140), GY - V(230, 260), V(130, 110), V(230, 260), 30); g.fillStyle = shade(M.wall, -0.3); g.fill();
    const lx = CX - V(720, 400);
    seg(g, [[lx, GY], [lx, GY - V(380, 420)]], 7, shade(M.wall, -0.5));
    rr(g, lx - 46, GY - V(430, 470), 92, 60, 10); g.fillStyle = alpha(M.practical, 0.35 + 0.6 * tod); g.fill();
    glow(g, lx, GY - V(400, 440), 300, M.practical, 0.15 + 0.5 * tod);
    g.fillStyle = linGrad(g, 0, GY - 40, 0, GY + 600, [shade(M.floor, 0.1), M.dark]); g.fillRect(-E.W, GY - 40, E.W * 3, E.H * 2);
    FX.floorLines(g, GY - 40, GY + 600, 'rgba(0,0,0,.2)', 0.07);
    FX.pool(g, CX, GY + 10, 460, 70, M.key, 0.24 * (1 - 0.6 * tod));
  });
  return { GY, CX, M, win: { x: wx, y: wy, w: ww, h: wh } };
}
