// cast.js — one outfit per recurring character. Signature colour = identity; keep it identical in every shot.
export const YOU = { top: 'hoodie', color: '#d64a33', head: 'none' };   // "you", the viewer
export const CAST = [YOU];
