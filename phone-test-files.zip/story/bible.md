# Bible — "5 Phone Habits Stealing Your Hours" (14 s test cut)
Logline: second-person hook. "You" lose a whole day ten seconds at a time to a phone. Tone: calm, slightly uneasy, then a quiet reveal.
## Cast
| id | role | outfit | signature | expressions |
|---|---|---|---|---|
| YOU | the viewer, hero | red-orange hoodie #d64a33, no hat | red hoodie | neutral, sleepy |
## Sets
- room (golden hour -> night): living room, big window with skyline, sofa, wall clock, floor lamp. Key light = window behind the hero (rim dir [0,-1]).
## Motifs
Cool phone-screen glow on the face. Window sky and wall clock show time racing by.
## Music
0-9.5 mystery .35 | 9.5-14.4 tension .55
