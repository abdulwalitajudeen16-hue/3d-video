# fix_words.py — tidy the caption words: "reset" -> "RESET", and drop the comma after "Comment".
import json, os, re, sys
proj = sys.argv[1] if len(sys.argv) > 1 else '.'
p = os.path.join(proj, 'timeline', 'words.json'); d = json.load(open(p)); n = 0
for w in d['words']:
    core = re.sub(r"[^\w']+", '', w['word']).lower(); tail = re.search(r'[^\w\']+$', w['word']); tail = tail.group(0) if tail else ''
    if core == 'reset': w['word'] = 'RESET' + tail; n += 1
    elif core == 'comment' and tail.strip() == ',': w['word'] = 'Comment'; n += 1
json.dump(d, open(p, 'w'), indent=1); print('fixed', n, 'caption words')
